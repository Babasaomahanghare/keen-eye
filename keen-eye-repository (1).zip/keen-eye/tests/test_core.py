import json
from pathlib import Path

import pytest
from PIL import Image

from keeneye.config import KeenEyeConfig, load_config, mask_key, save_config
from keeneye.errors import GeminiError, ImageValidationError
from keeneye.gemini import normalize_response, parse_response_text
from keeneye.image import validate_image
from keeneye.metadata import extract_metadata
from keeneye.reports import build_report, render_html, write_json
from keeneye.scoring import calculate_score


def make_image(path: Path):
    Image.new("RGB", (32, 20), (30, 80, 100)).save(path, format="PNG")


def test_config_environment_takes_precedence(monkeypatch, tmp_path):
    monkeypatch.setenv("KEEN_EYE_CONFIG_DIR", str(tmp_path))
    save_config("local-secret")
    monkeypatch.setenv("GEMINI_API_KEY", "environment-secret")
    assert load_config().api_key == "environment-secret"
    assert mask_key("environment-secret").endswith("cret")
    assert "environment-secret" not in mask_key("environment-secret")


def test_config_file_permissions(monkeypatch, tmp_path):
    monkeypatch.setenv("KEEN_EYE_CONFIG_DIR", str(tmp_path))
    path = save_config("safe-secret")
    assert path.exists()
    assert json.loads(path.read_text())["api_key"] == "safe-secret"


def test_image_validation_and_hashes(tmp_path):
    path = tmp_path / "sample.png"
    make_image(path)
    profile = validate_image(path)
    assert profile.format == "PNG"
    assert profile.width == 32
    assert len(profile.sha256) == 64


def test_missing_and_invalid_images(tmp_path):
    with pytest.raises(ImageValidationError):
        validate_image(tmp_path / "missing.png")
    invalid = tmp_path / "not-image.txt"
    invalid.write_text("nope")
    with pytest.raises(ImageValidationError):
        validate_image(invalid)


def test_metadata_does_not_invent_values(tmp_path):
    path = tmp_path / "sample.png"
    make_image(path)
    metadata = extract_metadata(path)
    assert metadata["gps"] is None
    assert metadata["camera_model"] is None


def test_malformed_gemini_response_is_actionable():
    with pytest.raises(GeminiError):
        parse_response_text("not json")
    with pytest.raises(GeminiError):
        normalize_response(["not", "an", "object"])


def test_gemini_fenced_json_is_normalized():
    result = parse_response_text('```json\n{"summary":"visible","visible_text":[]}\n```')
    assert result["summary"] == "visible"
    assert result["limitations"]
    assert result["people_present"] is None


def test_score_uses_actual_findings_only():
    score = calculate_score({"gps": None, "camera_model": None}, {
        "privacy_exposure": [{"observation": "sign"}],
        "visible_text": [], "signage": [], "location_clues": [],
        "security_relevant_observations": [],
    })
    assert score["score"] == 8
    empty = calculate_score({}, {})
    assert empty["score"] == 0
    assert empty["reasons"] == []


def test_json_and_html_reports(tmp_path):
    report = build_report(
        {"filename": "x.png", "format": "PNG", "mime_type": "image/png",
         "size_bytes": 10, "width": 1, "height": 1, "sha256": "x", "md5": "y"},
        {"gps": None, "camera_make": None, "camera_model": None, "datetime": None,
         "software": None},
        {"summary": "safe", "visible_text": [], "limitations": ["verify"]},
        {"score": 0, "band": "LOW EXPOSURE", "reasons": []},
    )
    path = write_json(report, tmp_path / "report.json")
    assert json.loads(path.read_text())["product"] == "KEEN EYE"
    html = render_html(report)
    assert "KEEN EYE" in html
    assert "<script" not in html.lower()


def test_analyzer_uses_mock_client(tmp_path):
    from keeneye.analyzer import analyze_image

    path = tmp_path / "sample.png"
    make_image(path)

    class FakeClient:
        def analyze(self, image_bytes, mime_type):
            assert image_bytes
            assert mime_type == "image/png"
            return {"summary": "mock", "visible_text": [], "privacy_exposure": []}

    report = analyze_image(
        str(path), KeenEyeConfig(api_key="test-key"), consent=True,
        client=FakeClient()
    )
    assert report["ai_visual_intelligence"]["summary"] == "mock"